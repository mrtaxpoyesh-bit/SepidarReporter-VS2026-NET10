# 🚀 راه‌اندازی سریع - Sepidar Reporter

## دو راه ساده برای شروع:

### ⚡ راه اول: استفاده از START-ALL.bat (توصیه می‌شود)

1. دابل کلیک روی `START-ALL.bat`
2. صبر کنید تا Backend آماده شود (10 ثانیه)
3. Frontend خودکار در مرورگر باز می‌شود
4. وارد سیستم شوید با:
   - **Email:** admin@sepidar.com
   - **Password:** Admin123!

### 🎯 راه دوم: اجرای دستی

#### مرحله ۱: Backend
```cmd
cd Backend
dotnet restore
dotnet run
```

منتظر بمانید تا این پیام ظاهر شود:
```
Now listening on: https://localhost:7001
```

#### مرحله ۲: Frontend

دابل کلیک روی `Frontend/index.html`

---

## 📋 پیش‌نیازها

قبل از اجرا، اطمینان حاصل کنید که موارد زیر نصب شده‌اند:

✅ **Visual Studio 2026** (Community/Professional/Enterprise)
✅ **.NET SDK 10.0** - بررسی نسخه:
```cmd
dotnet --version
```
باید 10.0.x یا بالاتر نشان دهد.

✅ **SQL Server 2019+** یا **SQL Server LocalDB**

اگر .NET SDK نصب نیست:
👉 [دانلود .NET 10](https://dotnet.microsoft.com/download/dotnet/10.0)

---

## 🔐 ورود به سیستم

### حساب‌های آزمایشی:

| نقش | ایمیل | رمز عبور |
|-----|-------|----------|
| 🔑 مدیر | admin@sepidar.com | Admin123! |
| 👤 کاربر | user@sepidar.com | User123! |
| 📊 حسابدار | accountant@sepidar.com | Accountant123! |

---

## 📊 استفاده از سیستم

### گام ۱: اتصال به دیتابیس
- روش ۱: وارد کردن Connection String مستقیم SQL Server
- روش ۲: آپلود فایل بکاپ سپیدار (.bak, .backup, .sql)

### گام ۲: تولید گزارش
۱۳ نوع گزارش در دسترس است:
- ترازنامه (Balance Sheet)
- صورت سود و زیان (Income Statement)
- جریان وجه نقد (Cash Flow)
- دفتر کل (General Ledger)
- دفتر معین (Subsidiary Ledger)
- و ۸ گزارش دیگر...

### گام ۳: صدور گزارش
فرمت‌های خروجی:
- 📊 Excel (با نمودارها)
- 📋 CSV (برای Power BI)
- 👁️ پیش‌نمایش آنلاین

---

## 🐛 مشکلات رایج

### Backend اجرا نمی‌شود
```cmd
# بررسی نسخه .NET
dotnet --version

# پاک کردن و ساخت مجدد
dotnet clean
dotnet restore
dotnet build
```

### Frontend به Backend وصل نمی‌شود
1. اطمینان حاصل کنید Backend در حال اجرا است
2. در مرورگر به این آدرس بروید: https://localhost:7001/swagger
3. اگر خطا دیدید، Backend را مجدداً اجرا کنید

### خطای دیتابیس
1. فایل `Backend/appsettings.json` را باز کنید
2. `ConnectionStrings:DefaultConnection` را بررسی کنید
3. اطمینان حاصل کنید SQL Server در حال اجرا است:
```cmd
net start MSSQL$SQLEXPRESS
```

---

## 📚 مستندات کامل

برای اطلاعات بیشتر، فایل `README.md` را مطالعه کنید.

## 🆘 کمک بیشتر

- 📖 Swagger API Docs: https://localhost:7001/swagger
- 💻 کنسول Backend: پیام‌های خطا و لاگ را بررسی کنید
- 🔍 Developer Console مرورگر (F12): خطاهای Frontend را ببینید

---

**موفق باشید! 🎉**
