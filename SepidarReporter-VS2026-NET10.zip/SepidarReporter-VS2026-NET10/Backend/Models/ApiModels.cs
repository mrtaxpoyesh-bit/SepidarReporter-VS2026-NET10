namespace SepidarReporter.Backend.Models;

public class LoginModel
{
    public required string Email { get; set; }
    public required string Password { get; set; }
}

public class LoginResponse
{
    public required string Token { get; set; }
    public required UserInfo User { get; set; }
}

public class UserInfo
{
    public required string Email { get; set; }
    public required string Name { get; set; }
    public required string Role { get; set; }
}

public class DatabaseConnectionRequest
{
    public required string Server { get; set; }
    public int Port { get; set; } = 1433;
    public required string Database { get; set; }
    public string AuthenticationType { get; set; } = "sql";
    public string? Username { get; set; }
    public string? Password { get; set; }
    public int Timeout { get; set; } = 30;
    public bool Encryption { get; set; } = false;
}

public class DatabaseConnectionResponse
{
    public bool Success { get; set; }
    public string? Message { get; set; }
    public int TablesFound { get; set; }
    public List<string>? Tables { get; set; }
}

public class ReportGenerationRequest
{
    public required string ReportType { get; set; }
    public required string Format { get; set; }
    public ReportFilters? Filters { get; set; }
}

public class ReportFilters
{
    public string? DateFrom { get; set; }
    public string? DateTo { get; set; }
    public string? CostCenter { get; set; }
    public string? AccountType { get; set; }
    public string? AccountNumber { get; set; }
    public decimal? MinAmount { get; set; }
}

public class ReportGenerationResponse
{
    public bool Success { get; set; }
    public string? Message { get; set; }
    public string? FileName { get; set; }
    public byte[]? FileData { get; set; }
    public List<Dictionary<string, object>>? PreviewData { get; set; }
}