using System.Data.SqlClient;

namespace SepidarReporter.Backend.Services;

public interface ISepidarDatabaseService
{
    Task<bool> TestConnectionAsync(string connectionString);
    Task<List<string>> GetTablesAsync(string connectionString);
}

public class SepidarDatabaseService : ISepidarDatabaseService
{
    private readonly ILogger<SepidarDatabaseService> _logger;

    public SepidarDatabaseService(ILogger<SepidarDatabaseService> logger)
    {
        _logger = logger;
    }

    public async Task<bool> TestConnectionAsync(string connectionString)
    {
        try
        {
            using var connection = new SqlConnection(connectionString);
            await connection.OpenAsync();
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error testing database connection");
            return false;
        }
    }

    public async Task<List<string>> GetTablesAsync(string connectionString)
    {
        var tables = new List<string>();
        
        try
        {
            using var connection = new SqlConnection(connectionString);
            await connection.OpenAsync();
            
            var command = new SqlCommand(
                "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE'",
                connection);
            
            using var reader = await command.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                tables.Add(reader.GetString(0));
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting tables");
        }
        
        return tables;
    }
}

public interface IReportService
{
    Task<byte[]> GenerateReportAsync(string reportType, string format, object filters);
}

public class ReportService : IReportService
{
    private readonly ILogger<ReportService> _logger;

    public ReportService(ILogger<ReportService> logger)
    {
        _logger = logger;
    }

    public async Task<byte[]> GenerateReportAsync(string reportType, string format, object filters)
    {
        // Implement report generation logic
        await Task.Delay(100); // Simulate work
        
        return Array.Empty<byte>();
    }
}

public interface IExcelExportService
{
    byte[] ExportToExcel(List<Dictionary<string, object>> data, string reportName);
}

public class ExcelExportService : IExcelExportService
{
    public byte[] ExportToExcel(List<Dictionary<string, object>> data, string reportName)
    {
        // Implement Excel export using EPPlus
        return Array.Empty<byte>();
    }
}