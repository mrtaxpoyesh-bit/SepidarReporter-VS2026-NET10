# 📦 محتویات بسته SepidarReporter-VS2026-NET10

## ✅ فایل‌های موجود در پروژه

### 📂 ریشه پروژه
```
SepidarReporter-VS2026-NET10/
├── 📄 SepidarReporter.sln          # Solution File برای Visual Studio 2026
├── 📄 README.md                     # راهنمای کامل نصب و استفاده
├── 📄 QUICK-START.md                # راهنمای سریع شروع
├── 🚀 START-ALL.bat                 # اجرای همزمان Backend + Frontend
├── 🔧 START-BACKEND.bat             # اجرای فقط Backend
└── 🌐 START-FRONTEND.bat            # اجرای فقط Frontend
```

### 📂 Backend/ - پروژه ASP.NET Core Web API

```
Backend/
├── 📄 SepidarReporter.Backend.csproj    # فایل پروژه .NET 10
├── 📄 Program.cs                         # نقطه شروع برنامه
├── 📄 appsettings.json                   # تنظیمات (ConnectionString, JWT)
│
├── Controllers/                          # کنترلرهای API
│   └── AuthController.cs                 # احراز هویت (Login/Register)
│
├── Data/                                 # لایه دیتابیس
│   └── ApplicationDbContext.cs           # Entity Framework Context
│
├── Models/                               # مدل‌های داده
│   └── ApiModels.cs                      # Request/Response Models
│
└── Services/                             # لایه سرویس
    └── Services.cs                       # سرویس‌های اصلی (Database, Reports, Excel)
```

**توضیحات Backend:**
- **Framework:** ASP.NET Core 10.0 Web API
- **Authentication:** JWT Token با ASP.NET Identity
- **Database:** Entity Framework Core 10.0 با SQL Server
- **API Documentation:** Swagger/OpenAPI
- **پکیج‌های نصب شده:**
  - Microsoft.AspNetCore.Authentication.JwtBearer 10.0
  - Microsoft.EntityFrameworkCore.SqlServer 10.0
  - Swashbuckle.AspNetCore 7.0
  - ClosedXML 0.104.1 (صدور Excel)
  - Dapper 2.1.35 (کوئری‌های سریع)

### 📂 Frontend/ - رابط کاربری HTML/CSS/JS

```
Frontend/
├── 📄 index.html                    # صفحه اصلی (انتخاب Demo یا Full)
├── 📄 login.html                    # صفحه ورود (Full با Backend)
├── 📄 login-demo.html               # صفحه ورود (Demo بدون Backend)
├── 📄 dashboard.html                # داشبورد اصلی (Full)
├── 📄 dashboard-demo.html           # داشبورد (Demo)
├── 📄 database.html                 # مدیریت اتصال دیتابیس
├── 📄 reports.html                  # تولید گزارش‌ها (۱۳ نوع)
├── 📄 history.html                  # تاریخچه گزارش‌های تولید شده
├── 📄 settings.html                 # تنظیمات سیستم
├── 📄 README.md                     # راهنمای Frontend
└── 📄 TROUBLESHOOTING.md            # راهنمای عیب‌یابی
```

**توضیحات Frontend:**
- **تکنولوژی:** HTML5, CSS3, Vanilla JavaScript
- **طراحی:** Responsive با RTL Support کامل فارسی
- **تم‌ها:** ۳ تم رنگی (روشن، تیره، آبی)
- **ویژگی‌ها:**
  - ۱۳ نوع گزارش حسابداری
  - اتصال مستقیم به SQL Server سپیدار
  - پشتیبانی از فایل‌های بکاپ (.bak, .backup, .sql)
  - صدور به Excel/CSV با نمودارها
  - مدیریت تاریخچه و فیلترهای پیشرفته

---

## 🎯 گزارش‌های موجود (۱۳ نوع)

1. **ترازنامه (Balance Sheet)** - وضعیت دارایی‌ها و بدهی‌ها
2. **صورت وضعیت مالی (Statement of Financial Position)** - جزئیات مالی
3. **صورت سود و زیان (Income Statement)** - درآمد و هزینه‌ها
4. **جریان وجه نقد (Cash Flow Statement)** - جریان نقدینگی
5. **دفتر کل (General Ledger)** - تمام تراکنش‌های حسابداری
6. **دفتر معین (Subsidiary Ledger)** - جزئیات هر حساب
7. **اسناد حسابداری (Accounting Documents)** - سند به سند
8. **حساب‌های دریافتنی (Accounts Receivable)** - طلبکاران
9. **حساب‌های پرداختنی (Accounts Payable)** - بدهکاران
10. **نسبت‌های مالی (Financial Ratios)** - تحلیل نسبت‌ها
11. **تحلیل بودجه (Budget Analysis)** - انحراف از بودجه
12. **تحلیل هزینه (Cost Analysis)** - هزینه‌های مراکز
13. **گزارش مالیاتی (Tax Report)** - محاسبات مالیاتی

---

## 📊 آمار پروژه

| مورد | تعداد |
|------|-------|
| **فایل‌های Backend (.cs)** | ۴ فایل اصلی |
| **فایل‌های Frontend (.html)** | ۱۱ صفحه |
| **فایل‌های BAT** | ۳ فایل راه‌انداز |
| **فایل‌های مستندات (.md)** | ۴ فایل |
| **حجم ZIP** | ~۷۳ KB (فشرده‌شده) |
| **خطوط کد Backend** | ~۱۵۰۰ خط C# |
| **خطوط کد Frontend** | ~۴۰۰۰ خط HTML/CSS/JS |

---

## 🔧 پیش‌نیازهای سیستم

### نرم‌افزار:
- ✅ Windows 11 (یا Windows 10)
- ✅ Visual Studio 2026 (Community/Professional/Enterprise)
- ✅ .NET SDK 10.0 یا بالاتر
- ✅ SQL Server 2019+ یا LocalDB
- ✅ مرورگر مدرن (Chrome, Edge, Firefox)

### سخت‌افزار توصیه شده:
- 💻 CPU: 4 Cores یا بیشتر
- 🧠 RAM: 8 GB یا بیشتر
- 💾 فضای دیسک: 2 GB (برای .NET SDK و پروژه)

---

## 🚀 سه راه اجرای پروژه

### راه ۱: START-ALL.bat (ساده‌ترین)
```
دابل کلیک روی START-ALL.bat
→ Backend و Frontend خودکار اجرا می‌شوند
```

### راه ۲: Visual Studio 2026
```
باز کردن SepidarReporter.sln
→ F5 برای اجرا
→ Frontend را دستی باز کنید (index.html)
```

### راه ۳: Command Line
```cmd
cd Backend
dotnet restore && dotnet run

# در ترمینال جدید:
cd Frontend
start index.html
```

---

## 🔐 حساب‌های آزمایشی

| نقش | ایمیل | رمز عبور | دسترسی |
|-----|-------|----------|--------|
| 🔑 مدیر | admin@sepidar.com | Admin123! | کامل |
| 👤 کاربر | user@sepidar.com | User123! | محدود |
| 📊 حسابدار | accountant@sepidar.com | Accountant123! | گزارش‌ها |

⚠️ **نکته امنیتی:** بعد از ورود اول، حتماً رمز عبور را تغییر دهید!

---

## 🌐 URLهای مهم پس از اجرا

| سرویس | آدرس | توضیح |
|--------|------|-------|
| 🔗 Backend API | https://localhost:7001 | API اصلی |
| 📚 Swagger UI | https://localhost:7001/swagger | مستندات API |
| 🌐 Frontend | file:///...Frontend/index.html | رابط کاربری |

---

## 📝 فایل‌های تنظیمات

### Backend/appsettings.json
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\mssqllocaldb;..."
  },
  "JwtSettings": {
    "SecretKey": "...",
    "ExpiryMinutes": 60
  }
}
```

**تنظیمات قابل تغییر:**
- `DefaultConnection`: آدرس SQL Server
- `SecretKey`: کلید امنیتی JWT (حتماً تغییر دهید!)
- `ExpiryMinutes`: مدت اعتبار Token

---

## 🐛 مشکلات احتمالی و راه‌حل

### ❌ خطا: "dotnet command not found"
**راه‌حل:** .NET SDK نصب نیست
```
دانلود: https://dotnet.microsoft.com/download/dotnet/10.0
```

### ❌ خطا: "Unable to connect to database"
**راه‌حل:** SQL Server در حال اجرا نیست
```cmd
net start MSSQL$SQLEXPRESS
```

### ❌ خطا: "CORS Policy blocked"
**راه‌حل:** Backend اجرا نشده یا CORS تنظیم نشده
```
مطمئن شوید START-BACKEND.bat اجرا شده است
```

### ❌ خطا: "Port 7001 already in use"
**راه‌حل:** پورت اشغال است
```cmd
netstat -ano | findstr :7001
taskkill /PID [شماره_پروسه] /F
```

---

## 📚 مستندات بیشتر

برای اطلاعات دقیق‌تر، این فایل‌ها را مطالعه کنید:
- 📖 `README.md` - راهنمای کامل پروژه
- ⚡ `QUICK-START.md` - شروع سریع
- 🛠️ `Frontend/TROUBLESHOOTING.md` - عیب‌یابی Frontend

---

## 🎉 پیام پایانی

همه چیز آماده است! برای شروع:
```
1️⃣ استخراج فایل ZIP
2️⃣ دابل کلیک روی START-ALL.bat
3️⃣ ورود با admin@sepidar.com / Admin123!
4️⃣ لذت ببرید از گزارش‌گیری حرفه‌ای! 🚀
```

**موفق و پیروز باشید! 💪**

---

**تاریخ ایجاد:** ۱۱ دی ۱۴۰۴ (۱ ژانویه ۲۰۲۶)
**نسخه:** 1.0.0 - Visual Studio 2026 Edition
**سازگاری:** .NET 10.0, Windows 11, SQL Server 2019+
