# 🚀 سیستم گزارش‌گیری سپیدار - ویژه Visual Studio 2026 و .NET 10

[![.NET Version](https://img.shields.io/badge/.NET-10.0-512BD4?logo=dotnet)](https://dotnet.microsoft.com/)
[![Visual Studio](https://img.shields.io/badge/Visual%20Studio-2026-5C2D91?logo=visual-studio)](https://visualstudio.microsoft.com/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

## 📋 معرفی

سیستم **Sepidar Reporter** یک پلتفرم کامل و حرفه‌ای برای استخراج و تولید گزارش‌های حسابداری از نرم‌افزار سپیدار است. این سیستم با استفاده از آخرین فناوری‌های .NET 10 و Visual Studio 2026 توسعه یافته است.

### ✨ ویژگی‌های اصلی

#### 🎯 بک‌اند (Backend)
- **فریمورک:** ASP.NET Core 10.0 Web API
- **پایگاه داده:** SQL Server با Entity Framework Core 10.0
- **احراز هویت:** JWT Token با ASP.NET Identity
- **امنیت:** CORS Policy، Password Hashing، Role-Based Authorization
- **API Documentation:** Swagger/OpenAPI با UI تعاملی

#### 🎨 فرانت‌اند (Frontend)
- **۱۳ نوع گزارش حسابداری کامل:** ترازنامه، صورت سود و زیان، جریان وجه نقد، دفتر کل، دفتر معین، اسناد حسابداری، حساب‌های دریافتنی/پرداختنی، نسبت‌های مالی، تحلیل بودجه، تحلیل هزینه و گزارش مالیاتی
- **رابط کاربری مدرن:** طراحی Responsive با RTL Support کامل
- **۳ تم رنگی:** روشن، تیره، آبی
- **پشتیبانی از فرمت‌های خروجی:** Excel با نمودارها، CSV برای Power BI، پیش‌نمایش آنلاین
- **اتصال مستقیم به SQL Server سپیدار** و پشتیبانی از فایل‌های بکاپ (.bak/.backup/.sql)

---

## 📦 پیش‌نیازها

### نرم‌افزارهای مورد نیاز

1. **Visual Studio 2026** (هر نسخه: Community, Professional, Enterprise)
2. **.NET SDK 10.0** یا جدیدتر
3. **SQL Server 2019+** یا **SQL Server LocalDB**
4. **مرورگر وب مدرن** (Chrome, Edge, Firefox)

### بررسی نصب .NET SDK

برای اطمینان از نصب .NET 10، دستور زیر را در Command Prompt اجرا کنید:

```cmd
dotnet --version
```

خروجی باید **10.0.x** یا بالاتر باشد.

اگر نصب نیست، از لینک زیر دانلود کنید:
👉 [دانلود .NET 10 SDK](https://dotnet.microsoft.com/download/dotnet/10.0)

---

## 🚀 راه‌اندازی سریع

### روش ۱: استفاده از فایل‌های BAT (ساده‌ترین)

#### Windows 11:

1. **استخراج فایل ZIP** در یک پوشه (مثلاً `C:\Projects\SepidarReporter`)

2. **اجرای همه‌چیز با یک کلیک:**
   - دابل کلیک روی `START-ALL.bat`
   - Backend در `https://localhost:7001` اجرا می‌شود
   - Frontend در `http://localhost:3000` باز می‌شود

3. **اجرای جداگانه:**
   - Backend: دابل کلیک روی `START-BACKEND.bat`
   - Frontend: دابل کلیک روی `START-FRONTEND.bat`

### روش ۲: استفاده از Visual Studio 2026

1. **باز کردن Solution:**
   - فایل `SepidarReporter.sln` را دابل کلیک کنید
   - یا از منوی Visual Studio: `File > Open > Project/Solution`

2. **بازیابی پکیج‌ها:**
   - Visual Studio به‌طور خودکار NuGet Packages را بازیابی می‌کند
   - یا دستی: `Tools > NuGet Package Manager > Restore NuGet Packages`

3. **اجرای پروژه:**
   - Set `SepidarReporter.Backend` as Startup Project
   - کلیک روی `▶ Start` (یا `F5`)
   - Swagger UI در `https://localhost:7001/swagger` باز می‌شود

4. **باز کردن Frontend:**
   - فایل `Frontend/index.html` را در مرورگر باز کنید

### روش ۳: استفاده از Command Line

```cmd
# ورود به پوشه پروژه
cd C:\Projects\SepidarReporter

# اجرای Backend
cd Backend
dotnet restore
dotnet run

# در ترمینال جدید، اجرای Frontend
cd Frontend
start index.html
```

---

## 🔐 ورود به سیستم

### حساب‌های پیش‌فرض (Demo)

| نقش | ایمیل | رمز عبور |
|-----|-------|----------|
| مدیر سیستم | `admin@sepidar.com` | `Admin123!` |
| کاربر عادی | `user@sepidar.com` | `User123!` |
| حسابدار | `accountant@sepidar.com` | `Accountant123!` |

**نکته:** پس از ورود اولیه، حتماً رمز عبور را تغییر دهید.

---

## 📁 ساختار پروژه

```
SepidarReporter-VS2026-NET10/
│
├── SepidarReporter.sln              # Visual Studio Solution File
│
├── Backend/                         # پروژه ASP.NET Core Web API
│   ├── SepidarReporter.Backend.csproj
│   ├── Program.cs                   # نقطه شروع برنامه
│   ├── appsettings.json             # تنظیمات (ConnectionString, JWT)
│   │
│   ├── Controllers/                 # API Controllers
│   │   ├── AuthController.cs        # احراز هویت (Login/Register)
│   │   ├── DatabaseController.cs    # مدیریت دیتابیس
│   │   └── ReportsController.cs     # تولید گزارش‌ها
│   │
│   ├── Data/                        # Database Context
│   │   └── ApplicationDbContext.cs
│   │
│   ├── Models/                      # Data Models
│   │   ├── ApplicationUser.cs       # مدل کاربر
│   │   └── ApiModels.cs             # مدل‌های Request/Response
│   │
│   └── Services/                    # Business Logic
│       ├── SepidarDatabaseService.cs # اتصال به دیتابیس سپیدار
│       ├── ReportService.cs          # تولید گزارش‌ها
│       └── ExcelExportService.cs     # صدور به Excel
│
├── Frontend/                        # فایل‌های HTML/CSS/JS
│   ├── index.html                   # صفحه اصلی
│   ├── login.html                   # صفحه ورود
│   ├── dashboard.html               # داشبورد
│   ├── database.html                # مدیریت دیتابیس
│   ├── reports.html                 # تولید گزارش‌ها
│   ├── history.html                 # تاریخچه گزارش‌ها
│   └── settings.html                # تنظیمات
│
├── START-ALL.bat                    # اجرای همه‌چیز
├── START-BACKEND.bat                # اجرای فقط Backend
├── START-FRONTEND.bat               # اجرای فقط Frontend
│
└── README.md                        # این فایل
```

---

## 🔧 پیکربندی

### Backend Configuration

فایل `Backend/appsettings.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=SepidarReporter;Trusted_Connection=true;MultipleActiveResultSets=true;TrustServerCertificate=true"
  },
  "JwtSettings": {
    "SecretKey": "YOUR_SECRET_KEY_HERE",
    "Issuer": "SepidarReporter",
    "Audience": "SepidarReporterUsers",
    "ExpiryMinutes": 60
  }
}
```

**نکته:** برای محیط Production، حتماً `SecretKey` را تغییر دهید.

### Frontend Configuration

فایل‌های HTML به‌طور پیش‌فرض به `https://localhost:7001` متصل می‌شوند. برای تغییر:

در فایل‌های `login.html`, `dashboard.html`, و غیره، متغیر `API_BASE_URL` را ویرایش کنید:

```javascript
const API_BASE_URL = 'https://localhost:7001';
```

---

## 📊 استفاده از سیستم

### مراحل کار با سیستم:

1. **ورود به سیستم:**
   - با یکی از حساب‌های Demo وارد شوید

2. **اتصال به دیتابیس سپیدار:**
   - **روش ۱ (مستقیم):** Connection String دیتابیس SQL Server سپیدار را وارد کنید
   - **روش ۲ (بکاپ):** فایل `.bak` یا `.backup` سپیدار را آپلود کنید

3. **انتخاب نوع گزارش:**
   - از منوی Reports یکی از ۱۳ نوع گزارش را انتخاب کنید

4. **اعمال فیلترها:**
   - بازه تاریخ، مرکز هزینه، نوع حساب، محدوده مبلغ

5. **صدور گزارش:**
   - انتخاب فرمت خروجی (Excel، CSV، پیش‌نمایش)
   - دانلود فایل

---

## 🛠️ توسعه و سفارشی‌سازی

### اضافه کردن گزارش جدید:

1. **Backend:**
   - در `ReportService.cs` متد جدید بسازید:
     ```csharp
     public async Task<ReportResult> GenerateCustomReportAsync(string query)
     {
         // کد شما اینجا
     }
     ```
   
   - در `ReportsController.cs` endpoint جدید اضافه کنید:
     ```csharp
     [HttpPost("custom")]
     public async Task<IActionResult> GenerateCustomReport([FromBody] CustomReportRequest request)
     {
         var result = await _reportService.GenerateCustomReportAsync(request.Query);
         return Ok(result);
     }
     ```

2. **Frontend:**
   - در `reports.html` گزینه جدید در منو اضافه کنید
   - فرم مربوط به فیلترهای گزارش جدید بسازید

### تغییر طرح رنگی:

فایل‌های Frontend از CSS Variables استفاده می‌کنند. برای تغییر رنگ‌ها:

```css
:root {
    --primary-color: #your-color;
    --secondary-color: #your-color;
}
```

---

## 🐛 عیب‌یابی

### خطای "Unable to connect to Backend"

**علت:** Backend در حال اجرا نیست.

**راه‌حل:**
1. اطمینان حاصل کنید که `START-BACKEND.bat` اجرا شده است
2. در مرورگر به `https://localhost:7001/swagger` بروید و صحت اجرای API را بررسی کنید

### خطای "Database connection failed"

**علت:** SQL Server در حال اجرا نیست یا Connection String اشتباه است.

**راه‌حل:**
1. بررسی اجرای SQL Server:
   ```cmd
   net start MSSQL$SQLEXPRESS
   ```
2. ویرایش `appsettings.json` و بررسی Connection String

### خطای CORS

**علت:** CORS Policy اجازه دسترسی نمی‌دهد.

**راه‌حل:**
- در `Program.cs` بررسی کنید که CORS به‌درستی پیکربندی شده:
  ```csharp
  app.UseCors("AllowAll");
  ```

### گزارش نمی‌تواند تولید شود

**علت:** ساختار دیتابیس سپیدار با مدل‌های سیستم سازگار نیست.

**راه‌حل:**
- در `DatabaseController.cs` متد `TestConnection` را فراخوانی کنید
- جداول مورد نیاز را بررسی کنید

---

## 📚 مستندات API

پس از اجرای Backend، به آدرس زیر بروید:

👉 **Swagger UI:** [https://localhost:7001/swagger](https://localhost:7001/swagger)

### مهم‌ترین Endpoints:

#### Authentication

- `POST /api/auth/login` - ورود به سیستم
- `POST /api/auth/register` - ثبت‌نام کاربر جدید

#### Database Management

- `POST /api/database/connect` - اتصال به دیتابیس
- `POST /api/database/upload-backup` - آپلود فایل بکاپ
- `GET /api/database/tables` - لیست جداول

#### Reports

- `POST /api/reports/balance-sheet` - ترازنامه
- `POST /api/reports/income-statement` - صورت سود و زیان
- `POST /api/reports/cash-flow` - جریان وجه نقد
- `GET /api/reports/history` - تاریخچه گزارش‌ها

---

## 🔒 امنیت

### توصیه‌های امنیتی:

1. **تغییر رمز عبور پیش‌فرض:** حتماً پس از نصب رمز admin را تغییر دهید
2. **SecretKey قوی:** در `appsettings.json` از کلید طویل و تصادفی استفاده کنید
3. **HTTPS:** در Production فقط از HTTPS استفاده کنید
4. **Database Backup:** پشتیبان‌گیری منظم از دیتابیس
5. **Update Dependencies:** همیشه پکیج‌های NuGet را به‌روز نگه دارید

---

## 🆘 پشتیبانی

### منابع کمکی:

- 📖 [مستندات .NET 10](https://learn.microsoft.com/dotnet/)
- 🎥 [آموزش ASP.NET Core](https://www.youtube.com/results?search_query=asp.net+core+tutorial)
- 💬 [انجمن توسعه‌دهندگان](https://stackoverflow.com/questions/tagged/asp.net-core)

### گزارش مشکل:

اگر با مشکلی روبرو شدید:
1. فایل لاگ Backend را بررسی کنید
2. Developer Console مرورگر را چک کنید (F12)
3. با جزئیات کامل مشکل را گزارش دهید

---

## 📝 لایسنس

این پروژه تحت لایسنس MIT منتشر شده است.

---

## 🎉 تشکر

از استفاده از **Sepidar Reporter** متشکریم! 

برای سوالات و پیشنهادات، با ما در تماس باشید.

**موفق و پیروز باشید! 🚀**
