@echo off
chcp 65001 >nul
echo ========================================
echo 🚀 Sepidar Reporter - راه‌انداز کامل
echo ========================================
echo.
echo این فایل هم Backend و هم Frontend را اجرا می‌کند
echo.

cd /d "%~dp0"

echo [1/2] 🔧 راه‌اندازی Backend...
start "Sepidar Backend" cmd /k "cd /d "%~dp0Backend" && dotnet restore && dotnet run"

echo.
echo ⏳ صبر کنید تا Backend آماده شود (10 ثانیه)...
timeout /t 10 /nobreak >nul

echo.
echo [2/2] 🌐 باز کردن Frontend...
cd Frontend
start "" "index.html"

echo.
echo ========================================
echo ✅ سیستم آماده است!
echo ========================================
echo.
echo 📊 Backend API: https://localhost:7001
echo 📚 Swagger UI: https://localhost:7001/swagger
echo 🌐 Frontend: باز شد در مرورگر
echo.
echo 🔐 حساب آزمایشی:
echo    • Email: admin@sepidar.com
echo    • Password: Admin123!
echo.
echo 📝 برای توقف:
echo    • Backend: پنجره "Sepidar Backend" را ببندید
echo    • Frontend: تب مرورگر را ببندید
echo.
echo ========================================

pause
