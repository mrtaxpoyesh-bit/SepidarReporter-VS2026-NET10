@echo off
chcp 65001 >nul
echo ========================================
echo 🚀 Sepidar Reporter - Backend Starter
echo ========================================
echo.

cd /d "%~dp0Backend"

echo 📦 بررسی .NET SDK...
dotnet --version >nul 2>&1
if errorlevel 1 (
    echo ❌ .NET SDK نصب نشده است!
    echo 👉 لطفاً .NET 10 SDK را از https://dotnet.microsoft.com/download نصب کنید
    pause
    exit /b 1
)

echo ✅ .NET SDK موجود است
echo.

echo 📥 بازیابی پکیج‌های NuGet...
dotnet restore

echo.
echo 🏗️ ساخت پروژه...
dotnet build

echo.
echo 🚀 اجرای Backend...
echo 📊 API Base URL: https://localhost:7001
echo 📚 Swagger UI: https://localhost:7001/swagger
echo.
echo ⚠️  برای توقف سرور، Ctrl+C را فشار دهید
echo.

dotnet run

pause
