# 🏢 سیستم جامع گزارش‌گیری سپیدار - Frontend

سیستم کامل رابط کاربری (Frontend) برای گزارش‌گیری از نرم‌افزار حسابداری سپیدار با قابلیت‌های پیشرفته و رابط کاربری مدرن.

## 📋 فهرست محتویات

- [ویژگی‌های کلیدی](#ویژگیهای-کلیدی)
- [ساختار پروژه](#ساختار-پروژه)
- [نحوه راه‌اندازی](#نحوه-راهاندازی)
- [راهنمای استفاده](#راهنمای-استفاده)
- [صفحات سیستم](#صفحات-سیستم)
- [تنظیمات](#تنظیمات)
- [امنیت](#امنیت)
- [پشتیبانی](#پشتیبانی)

## 🎯 ویژگی‌های کلیدی

### 🔐 احراز هویت و امنیت
- سیستم ورود امن با JWT Authentication
- حساب‌های آزمایشی آماده
- مدیریت نشست کاربری
- خروج خودکار برای امنیت

### 🏠 داشبورد هوشمند
- آمار زنده سیستم
- وضعیت اتصال پایگاه داده
- دسترسی سریع به عملکردها
- نمایش آخرین فعالیت‌ها

### 🗄️ مدیریت پایگاه داده
- اتصال مستقیم به SQL Server
- پشتیبانی از فایل‌های بکاپ (.bak, .backup, .sql)
- drag & drop برای آپلود
- تشخیص خودکار جداول

### 📊 سیستم گزارش‌گیری
- **13 نوع گزارش مختلف:**
  - ترازنامه (Trial Balance)
  - صورت وضعیت مالی
  - صورت سود و زیان
  - صورت جریان وجه نقد
  - دفتر کل
  - دفتر معین
  - سند حسابداری
  - حساب‌های پرداختنی
  - حساب‌های دریافتنی
  - نسبت‌های مالی
  - انحراف بودجه
  - تحلیل هزینه
  - گزارش مالیاتی

### 🎨 رابط کاربری مدرن
- **طراحی Responsive** - سازگار با موبایل و تبلت
- **زبان فارسی** - کاملاً RTL
- **تم‌های مختلف** - روشن، تیره، آبی
- **انیمیشن‌های نرم** - تجربه کاربری بهتر

### 📈 فیلترهای پیشرفته
- فیلتر بر اساس تاریخ
- انتخاب مرکز هزینه
- نوع حساب
- محدوده مبلغ
- شماره حساب

### 📤 صدور گزارشات
- **Excel** - با قالب‌بندی و نمودارها
- **CSV** - برای Power BI
- **پیش‌نمایش آنلاین** - بدون دانلود

### 📋 مدیریت تاریخچه
- نمایش تمام گزارشات تولید شده
- دانلود مجدد فایل‌ها
- فیلتر و جستجو
- حذف دسته‌جمعی

### ⚙️ تنظیمات جامع
- مدیریت حساب کاربری
- تنظیمات امنیتی
- پیکربندی گزارشات
- مدیریت پایگاه داده

## 📁 ساختار پروژه

```
FRONTEND-COMPLETE/
├── 📄 login.html          # صفحه ورود
├── 🏠 dashboard.html      # داشبورد اصلی
├── 🗄️ database.html       # اتصال پایگاه داده
├── 📊 reports.html        # تولید گزارشات
├── 📋 history.html        # تاریخچه گزارشات
├── ⚙️ settings.html       # تنظیمات سیستم
└── 📖 README.md          # راهنمای استفاده
```

## 🚀 نحوه راه‌اندازی

### 1️⃣ آماده‌سازی سرور
```bash
# اطمینان از اجرای Backend
cd SepidarReporter.Backend
dotnet run
# سرور در https://localhost:7001 اجرا می‌شود
```

### 2️⃣ راه‌اندازی Frontend
```bash
# باز کردن فایل login.html در مرورگر
# یا استفاده از Live Server
```

### 3️⃣ ورود به سیستم
- **مدیر سیستم:**
  - ایمیل: `admin@sepidar.com`
  - رمز عبور: `Admin123!`

- **کاربر عادی:**
  - ایمیل: `user@sepidar.com`
  - رمز عبور: `User123!`

- **حسابدار:**
  - ایمیل: `accountant@sepidar.com`
  - رمز عبور: `Account123!`

## 📖 راهنمای استفاده

### مرحله 1: ورود به سیستم 🔐
1. فایل `login.html` را در مرورگر باز کنید
2. یکی از حساب‌های آزمایشی را انتخاب کنید
3. روی credentials کلیک کنید تا فرم پر شود
4. روی "ورود به سیستم" کلیک کنید

### مرحله 2: اتصال به پایگاه داده 🗄️
1. از داشبورد روی "اتصال پایگاه داده" کلیک کنید
2. **روش اول - اتصال مستقیم:**
   - Server: `localhost` یا IP سرور
   - Database: نام دیتابیس سپیدار
   - Username/Password: اطلاعات ورود
   
3. **روش دوم - فایل بکاپ:**
   - فایل .bak را drag & drop کنید
   - یا روی "انتخاب فایل" کلیک کنید

### مرحله 3: تولید گزارش 📊
1. نوع گزارش مورد نظر را انتخاب کنید
2. فیلترهای دلخواه را اعمال کنید:
   - بازه تاریخ
   - مرکز هزینه
   - نوع حساب
3. فرمت خروجی را انتخاب کنید (Excel/CSV/Preview)
4. روی "تولید گزارش" کلیک کنید

### مرحله 4: مدیریت تاریخچه 📋
1. مشاهده تمام گزارشات تولید شده
2. دانلود مجدد فایل‌ها
3. فیلتر بر اساس تاریخ یا نوع
4. حذف گزارشات غیرضروری

### مرحله 5: تنظیمات ⚙️
1. **حساب کاربری:** ویرایش پروفایل، تغییر رمز
2. **سیستم:** انتخاب تم، زبان، تنظیمات عمومی  
3. **امنیت:** 2FA، مدت نشست، رمزگذاری
4. **گزارشات:** فرمت پیش‌فرض، قالب‌بندی
5. **پایگاه داده:** مدیریت اتصال، پشتیبان‌گیری

## 📄 صفحات سیستم

### 🔐 Login (login.html)
- فرم ورود امن
- حساب‌های آزمایشی
- پیام‌های خطا/موفقیت
- انیمیشن loading

### 🏠 Dashboard (dashboard.html) 
- آمار کلی سیستم
- وضعیت اتصال پایگاه داده
- دسترسی سریع به بخش‌ها
- آخرین فعالیت‌ها

### 🗄️ Database (database.html)
- اتصال مستقیم SQL Server
- آپلود فایل بکاپ
- تست اتصال
- نمایش وضعیت

### 📊 Reports (reports.html)
- 13 نوع گزارش حسابداری
- فیلترهای پیشرفته
- صدور Excel/CSV/Preview
- پیش‌نمایش آنلاین

### 📋 History (history.html)
- فهرست تمام گزارشات
- فیلتر و جستجو
- دانلود مجدد
- مدیریت دسته‌جمعی

### ⚙️ Settings (settings.html)
- مدیریت حساب کاربری
- تنظیمات سیستم
- پیکربندی امنیت
- مدیریت پایگاه داده

## 🔧 تنظیمات

### تنظیمات سیستم
```javascript
// localStorage keys
systemSettings = {
    theme: 'light|dark|blue',
    language: 'fa|en',
    timezone: 'Asia/Tehran',
    notifications: true|false,
    autoSave: true|false
}
```

### تنظیمات امنیت
```javascript
securitySettings = {
    twoFactorAuth: true|false,
    sessionTimeout: 30, // minutes
    autoLogout: true|false,
    encryption: true|false
}
```

### تنظیمات گزارشات
```javascript
reportsSettings = {
    defaultFormat: 'excel|csv|preview',
    defaultDateRange: 'last_month',
    autoCharts: true|false,
    template: 'standard|professional'
}
```

## 🛡️ امنیت

### احراز هویت
- JWT Token Authentication
- Session Management  
- Auto Logout
- Secure Storage

### رمزگذاری
- Password Hashing
- Data Encryption
- Secure Transmission
- Token Expiry

### مجوزها
- Role-based Access
- Permission Levels
- Activity Logging
- Audit Trail

## 🌟 ویژگی‌های پیشرفته

### واکنش‌گرا (Responsive)
- موبایل: < 768px
- تبلت: 768px - 1024px  
- دسکتاپ: > 1024px

### دسترسی‌پذیری
- RTL Support
- Keyboard Navigation
- Screen Reader Compatible
- High Contrast Mode

### عملکرد
- Lazy Loading
- Cache Management
- Optimized Assets
- Fast Rendering

## 🔄 یکپارچه‌سازی با Backend

### API Endpoints
```javascript
const API_BASE = 'https://localhost:7001/api';

// Authentication
POST /api/auth/login
POST /api/auth/change-password

// Database
POST /api/database/connect
POST /api/database/test-connection
POST /api/database/upload-backup

// Reports
POST /api/reports/generate
GET /api/reports/history
GET /api/reports/download/{id}

// Dashboard
GET /api/dashboard/statistics
GET /api/dashboard/recent-activity
```

### Request Format
```javascript
headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' + token
}
```

## 🎨 تم‌ها و ظاهر

### تم روشن (Light)
- پس‌زمینه: سفید
- متن: خاکستری تیره
- لینک‌ها: آبی

### تم تیره (Dark)  
- پس‌زمینه: خاکستری تیره
- متن: سفید
- لینک‌ها: آبی روشن

### تم آبی (Blue)
- پس‌زمینه: آبی گرادینت
- متن: سفید
- لینک‌ها: زرد

## 📱 پشتیبانی مرورگرها

- ✅ Chrome 70+
- ✅ Firefox 65+
- ✅ Safari 12+
- ✅ Edge 79+
- ❌ Internet Explorer

## 🐛 عیب‌یابی

### مشکلات رایج

**1. صفحه لاگین بارگذاری نمی‌شود:**
- بررسی اتصال اینترنت
- چک کردن Console برای خطاها
- خاکسازی Cache مرورگر

**2. خطای اتصال به API:**
```javascript
// بررسی آدرس Backend
const API_BASE = 'https://localhost:7001/api';
```

**3. مشکل در نمایش فارسی:**
- اطمینان از وجود فونت‌های فارسی
- بررسی direction: rtl
- چک کردن encoding صفحه

**4. گزارش تولید نمی‌شود:**
- بررسی اتصال پایگاه داده
- چک کردن مجوزهای کاربری
- بررسی لاگ‌های سرور

### ابزارهای توسعه
```javascript
// فعال‌سازی Debug Mode
localStorage.setItem('debugMode', 'true');

// مشاهده لاگ‌ها
console.log('Debug info:', debugData);
```

## 📞 پشتیبانی

### اطلاعات تماس
- **ایمیل پشتیبانی:** support@sepidar-reporter.com
- **تلفن:** 021-12345678
- **آدرس:** تهران، خیابان ولیعصر

### مستندات
- راهنمای کاربری: `user-manual.pdf`
- راهنمای مدیر: `admin-guide.pdf`  
- API Documentation: `api-docs.html`

### آپدیت‌ها
- نسخه فعلی: v1.0.0
- آخرین بروزرسانی: 2024-01-15
- Change Log: `CHANGELOG.md`

---

## 🏆 ویژگی‌های کلیدی سیستم

✅ **مدیریت کامل پایگاه داده** - اتصال مستقیم + فایل بکاپ  
✅ **13 نوع گزارش حسابداری** - کامل و حرفه‌ای  
✅ **رابط کاربری مدرن** - Responsive + RTL  
✅ **امنیت پیشرفته** - JWT + Session Management  
✅ **صدور چندفرمته** - Excel + CSV + Preview  
✅ **فیلترهای قدرتمند** - تاریخ + مرکز هزینه + ...  
✅ **تاریخچه کامل** - مدیریت فایل‌های صادر شده  
✅ **تنظیمات جامع** - شخصی‌سازی کامل  

---

**🎯 آماده برای استفاده در محیط تولید!**