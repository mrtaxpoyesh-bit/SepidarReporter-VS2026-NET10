# 🔧 راهنمای رفع مشکل "Load Failed"

## 🚨 مشکل: خطای "Load Failed" در صفحه لاگین

وقتی صفحه `login.html` را باز می‌کنید، پیغام **"Load failed"** نمایش داده می‌شود.

### 🔍 دلیل مشکل:

Frontend تلاش می‌کند به Backend در آدرس `https://localhost:7001/api` متصل شود، اما:
1. Backend اجرا نشده است، یا
2. مشکل CORS وجود دارد، یا  
3. پورت Backend اشتباه است، یا
4. گواهی SSL مشکل دارد

---

## ✅ راه‌حل‌ها:

### **روش 1️⃣: استفاده از نسخه Demo (بدون Backend)**

اگر فقط می‌خواهید رابط کاربری را **ببینید** و تست کنید:

#### **فایل‌های Demo:**
- **[login-demo.html](computer:///mnt/user-data/outputs/FRONTEND-COMPLETE/login-demo.html)** - صفحه ورود Demo
- **[dashboard-demo.html](computer:///mnt/user-data/outputs/FRONTEND-COMPLETE/dashboard-demo.html)** - داشبورد Demo

#### **نحوه استفاده:**
1. فایل `login-demo.html` را در مرورگر باز کنید
2. روی یکی از حساب‌های آزمایشی کلیک کنید:
   - **مدیر:** `admin@sepidar.com` / `Admin123!`
   - **کاربر:** `user@sepidar.com` / `User123!`
   - **حسابدار:** `accountant@sepidar.com` / `Account123!`
3. روی "ورود به سیستم" کلیک کنید

✅ **مزایا:** بدون نیاز به Backend، سریع و آسان  
❌ **محدودیت:** داده‌ها شبیه‌سازی شده هستند

---

### **روش 2️⃣: اجرای Backend و اتصال واقعی**

اگر می‌خواهید سیستم **واقعاً** کار کند:

#### **مرحله 1: اجرای Backend**

```bash
# رفتن به پوشه Backend
cd /mnt/user-data/outputs/SepidarReporter.Backend

# نصب وابستگی‌ها
dotnet restore

# ایجاد دیتابیس
dotnet ef migrations add InitialCreate
dotnet ef database update

# اجرای Backend
dotnet run
```

باید پیغامی شبیه این ببینید:
```
Now listening on: https://localhost:7001
Now listening on: http://localhost:5000
```

#### **مرحله 2: حل مشکل گواهی SSL**

اگر مرورگر خطای SSL می‌دهد:

**برای Windows:**
```bash
dotnet dev-certs https --trust
```

**برای Mac/Linux:**
```bash
dotnet dev-certs https --clean
dotnet dev-certs https
```

#### **مرحله 3: باز کردن Frontend**

حالا فایل‌های اصلی را باز کنید:
- `login.html`
- `dashboard.html`  
- `database.html`
- `reports.html`

✅ **مزایا:** عملکرد کامل، اتصال واقعی به دیتابیس  
❌ **نیازمندی:** نصب .NET 8.0 SDK، اجرای Backend

---

### **روش 3️⃣: تغییر آدرس Backend**

اگر Backend روی پورت دیگری اجرا می‌شود:

در فایل‌های Frontend (`login.html`, `dashboard.html`, etc.) این خط را پیدا کنید:

```javascript
const API_BASE = 'https://localhost:7001/api';
```

و آن را به پورت صحیح تغییر دهید:

```javascript
const API_BASE = 'http://localhost:5000/api';  // یا هر پورت دیگر
```

---

### **روش 4️⃣: غیرفعال کردن HTTPS (توسعه محلی)**

اگر می‌خواهید از HTTP استفاده کنید:

در `Program.cs` خط زیر را کامنت کنید:

```csharp
// app.UseHttpsRedirection();
```

و در Frontend آدرس را تغییر دهید:

```javascript
const API_BASE = 'http://localhost:5000/api';
```

---

## 📊 مقایسه روش‌ها:

| ویژگی | Demo Mode | Backend واقعی |
|-------|-----------|---------------|
| نیاز به Backend | ❌ خیر | ✅ بله |
| اتصال دیتابیس | ❌ شبیه‌سازی | ✅ واقعی |
| تولید گزارش | ❌ نمونه | ✅ واقعی |
| سرعت راه‌اندازی | ⚡ فوری | 🐢 چند دقیقه |
| مناسب برای | پیش‌نمایش UI | استفاده واقعی |

---

## 🛠️ عیب‌یابی:

### مشکل 1: Backend اجرا نمی‌شود
```bash
# بررسی نسخه .NET
dotnet --version

# باید 8.0 یا بالاتر باشد
# اگر نبود:
# دانلود از: https://dotnet.microsoft.com/download
```

### مشکل 2: خطای دیتابیس
```bash
# پاک کردن و ساخت دوباره
dotnet ef database drop --force
dotnet ef migrations remove
dotnet ef migrations add InitialCreate
dotnet ef database update
```

### مشکل 3: پورت اشغال است
```bash
# تغییر پورت در appsettings.json
{
  "Kestrel": {
    "Endpoints": {
      "Http": { "Url": "http://localhost:5001" },
      "Https": { "Url": "https://localhost:7002" }
    }
  }
}
```

### مشکل 4: CORS Error
در `Program.cs` بررسی کنید:
```csharp
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

// در middleware:
app.UseCors("AllowAll");
```

---

## 📝 خلاصه توصیه:

### برای **تست سریع UI:**
👉 استفاده از فایل‌های Demo:
- `login-demo.html`
- `dashboard-demo.html`

### برای **استفاده واقعی:**
👉 اجرای Backend + استفاده از فایل‌های اصلی:
- `login.html`
- `dashboard.html`
- `database.html`
- `reports.html`
- `history.html`
- `settings.html`

---

## 📞 پشتیبانی:

اگر مشکل همچنان حل نشد:

1. **بررسی Console مرورگر** (F12 > Console)
2. **بررسی لاگ Backend** (terminal که dotnet run اجرا شده)
3. **تست آدرس Backend** در مرورگر: `https://localhost:7001/swagger`

---

**✅ با هر دو روش، می‌توانید سیستم را ببینید و تست کنید!**