@echo off
chcp 65001 >nul
echo ========================================
echo 🎨 Sepidar Reporter - Frontend Starter
echo ========================================
echo.

cd /d "%~dp0Frontend"

echo 🌐 باز کردن Frontend در مرورگر پیش‌فرض...
echo 📍 URL: file:///%CD%\index.html
echo.

start "" "index.html"

echo ✅ Frontend باز شد!
echo.
echo 📝 نکات مهم:
echo    • Backend باید در حال اجرا باشد (START-BACKEND.bat)
echo    • URL API: https://localhost:7001
echo    • حساب آزمایشی: admin@sepidar.com / Admin123!
echo.

pause
